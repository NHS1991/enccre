var config = {
	visorToken: "YwpYbdby"
};
